export const mapTypeDefinitions = {
  administrative: {
    label: "States & Districts",
    simpleName: "Administrative Map",
    description:
      "Shows states, districts, cities, and official boundaries. Use this when you want to know where a place belongs.",
    examples: ["States", "Districts", "Cities", "Boundaries"],
  },
  tourism: {
    label: "Travel & Places",
    simpleName: "Tourism Map",
    description:
      "Shows attractions, food places, hotels, cultural areas, and places people may want to visit.",
    examples: ["Attractions", "Food", "Hotels", "Culture"],
  },
  transport: {
    label: "Roads & Transport",
    simpleName: "Transport Map",
    description:
      "Shows roads, highways, railways, stations, and how places are connected.",
    examples: ["Roads", "Highways", "Railways", "Stations"],
  },
  physical: {
    label: "Nature & Environment",
    simpleName: "Physical Map",
    description:
      "Shows natural features such as rivers, mountains, terrain, forests, and environmental areas.",
    examples: ["Rivers", "Mountains", "Forests", "Terrain"],
  },
};

export const demoScenarios = {
  general: {
    query: "What can I visit in Penang?",
    title: "Recommended places to explore in Penang",
    recommendedMapType: "tourism",
    focus: "George Town, Penang",
    summary:
      "George Town is a good starting point because it has cultural attractions, food areas, heritage streets, and nearby public facilities.",
    userFriendlyAnswer:
      "You can start around George Town. It is suitable for general exploration because it combines heritage streets, cafes, museums, and nearby transport access. For a first visit, focus on the heritage core, nearby food streets, and waterfront areas.",
    relatedPlaces: [
      { name: "George Town Heritage Area", type: "Cultural Area", note: "Good for walking and sightseeing." },
      { name: "Penang Street Food Zone", type: "Food Area", note: "Suitable for local food discovery." },
      { name: "Waterfront Area", type: "Scenic Place", note: "Good for evening visits." },
      { name: "Nearby Transport Stop", type: "Transport", note: "Useful for planning movement." },
    ],
    mapMarkers: [
      { label: "Heritage Area", x: 42, y: 42 },
      { label: "Food Street", x: 54, y: 56 },
      { label: "Waterfront", x: 66, y: 38 },
    ],
    steps: [
      "Detected that the question is about places to visit.",
      "Identified Penang and George Town as the main area.",
      "Selected the tourism map because attractions and food places are relevant.",
      "Highlighted suitable places and generated an easy answer.",
    ],
    graph: [
      ["George Town", "located in", "Penang"],
      ["George Town", "has attraction", "Heritage Area"],
      ["Food Street", "near", "George Town"],
      ["Waterfront", "suitable for", "Scenic Visit"],
    ],
  },
  tourism: {
    query: "Show tourism places in Selangor near hospitals",
    title: "Tourism places in Selangor with nearby facilities",
    recommendedMapType: "tourism",
    focus: "Selangor",
    summary:
      "The system selected the tourism map and checked nearby facilities to support safer trip planning.",
    userFriendlyAnswer:
      "Selangor has several suitable tourism areas with nearby public facilities. The highlighted places can help users explore attractions while staying close to hospitals or emergency services.",
    relatedPlaces: [
      { name: "Shah Alam", type: "City", note: "Main urban area with facilities." },
      { name: "Tourism Area", type: "Attraction Cluster", note: "Suitable for visitors." },
      { name: "Hospital POI", type: "Facility", note: "Nearby healthcare support." },
      { name: "Transport Access", type: "Transport", note: "Useful for reaching the area." },
    ],
    mapMarkers: [
      { label: "Shah Alam", x: 38, y: 54 },
      { label: "Tourism Area", x: 48, y: 46 },
      { label: "Hospital POI", x: 58, y: 57 },
    ],
    steps: [
      "Detected a tourism and facility-related query.",
      "Identified Selangor as the main location.",
      "Selected tourism and infrastructure-related map information.",
      "Highlighted attractions and nearby hospitals for easier planning.",
    ],
    graph: [
      ["Selangor", "contains", "Shah Alam"],
      ["Tourism Area", "located in", "Selangor"],
      ["Tourism Area", "near", "Hospital POI"],
      ["Hospital POI", "type", "Facility"],
    ],
  },
  logistics: {
    query: "Show industrial areas near highways in Johor",
    title: "Industrial areas with highway access in Johor",
    recommendedMapType: "transport",
    focus: "Johor",
    summary:
      "The system selected the transport map because the query is about highway access and industrial connectivity.",
    userFriendlyAnswer:
      "For logistics planning, the system highlights industrial areas that are close to highway routes. These areas are useful for checking transport access, warehouse suitability, and regional connectivity.",
    relatedPlaces: [
      { name: "Industrial Area", type: "Business Zone", note: "Suitable for logistics analysis." },
      { name: "Highway Route", type: "Road Network", note: "Supports regional movement." },
      { name: "Nearby City", type: "Urban Area", note: "Potential demand and workforce area." },
      { name: "Transport Node", type: "Connectivity", note: "Useful for accessibility checking." },
    ],
    mapMarkers: [
      { label: "Industrial Area", x: 50, y: 52 },
      { label: "Highway Route", x: 60, y: 43 },
      { label: "Transport Node", x: 42, y: 64 },
    ],
    steps: [
      "Detected a logistics and accessibility query.",
      "Identified Johor as the target area.",
      "Selected the transport map to show roads and connectivity.",
      "Highlighted industrial areas near highway routes.",
    ],
    graph: [
      ["Industrial Area", "located in", "Johor"],
      ["Industrial Area", "near", "Highway Route"],
      ["Highway Route", "connects", "Nearby City"],
      ["Transport Node", "supports", "Logistics Access"],
    ],
  },
  physical: {
    query: "Show flood risk areas in Kelantan",
    title: "Flood-risk context in Kelantan",
    recommendedMapType: "physical",
    focus: "Kelantan",
    summary:
      "The system selected the physical map because flood-risk questions are related to rivers, terrain, and environmental areas.",
    userFriendlyAnswer:
      "Kelantan is shown with a physical and environmental context. The highlighted areas represent a simplified flood-risk view using river buffer and district overlap logic.",
    relatedPlaces: [
      { name: "Kelantan", type: "State", note: "Main selected area." },
      { name: "River Buffer", type: "Environmental Area", note: "Used for nearby-risk checking." },
      { name: "Risk District", type: "District", note: "Area overlapping the risk zone." },
      { name: "Flood Layer", type: "Map Layer", note: "Visualizes affected areas." },
    ],
    mapMarkers: [
      { label: "Kelantan", x: 54, y: 28 },
      { label: "River Buffer", x: 46, y: 37 },
      { label: "Risk District", x: 60, y: 42 },
    ],
    steps: [
      "Detected an environmental or flood-related query.",
      "Identified Kelantan as the target area.",
      "Selected the physical map because rivers and terrain are relevant.",
      "Highlighted areas that overlap with the simplified flood-risk context.",
    ],
    graph: [
      ["Kelantan", "contains", "Risk District"],
      ["Risk District", "intersects", "River Buffer"],
      ["River Buffer", "distance", "500m"],
      ["Flood Layer", "visualizes", "Risk Area"],
    ],
  },
};

export const popularQueries = [
  "What can I visit in Penang?",
  "Show tourism places in Selangor near hospitals",
  "Show industrial areas near highways in Johor",
  "Show flood risk areas in Kelantan",
];
