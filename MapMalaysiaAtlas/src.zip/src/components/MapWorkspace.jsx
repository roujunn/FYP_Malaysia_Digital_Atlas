import React, { useMemo, useState } from "react";
import {
  Camera,
  Landmark,
  Route,
  Mountain,
  MapPin,
  Navigation,
  Info,
  Layers3,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { mapTypeDefinitions } from "../data/mockAtlasData";

const mapIcons = {
  administrative: Landmark,
  tourism: Camera,
  transport: Route,
  physical: Mountain,
};

const mapColors = {
  administrative: "blue",
  tourism: "rose",
  transport: "amber",
  physical: "emerald",
};

function MapWorkspace({ result, selectedMapType, setSelectedMapType }) {
  const [showLayerPanel, setShowLayerPanel] = useState(true);

  const selectedDefinition = useMemo(() => {
    return mapTypeDefinitions[selectedMapType] || mapTypeDefinitions.tourism;
  }, [selectedMapType]);

  return (
    <section className="map-workspace">
      <div className="workspace-header">
        <div>
          <span className="section-kicker">Map Result</span>
          <h2>{result.focus}</h2>
          <p>{result.summary}</p>
        </div>

        <button className="soft-button" onClick={() => setShowLayerPanel(!showLayerPanel)}>
          {showLayerPanel ? <ChevronLeft size={16} /> : <ChevronRight size={16} />}
          {showLayerPanel ? "Hide layers" : "Show layers"}
        </button>
      </div>

      <div className={`map-stage ${showLayerPanel ? "with-sidebar" : "sidebar-hidden"}`}>
        <aside className={`layer-sidebar ${showLayerPanel ? "open" : "collapsed"}`}>
          {showLayerPanel ? (
            <>
              <div className="layer-sidebar-title">
                <Info size={16} />
                <strong>Map Types</strong>
              </div>

              <div className="layer-buttons">
                {Object.entries(mapTypeDefinitions).map(([key, item]) => {
                  const Icon = mapIcons[key];
                  const active = selectedMapType === key;
                  return (
                    <button
                      key={key}
                      className={`layer-button ${active ? "active" : ""} ${mapColors[key]}`}
                      onClick={() => setSelectedMapType(key)}
                    >
                      <Icon size={18} />
                      <span>{item.label}</span>
                    </button>
                  );
                })}
              </div>

              <div className={`map-definition ${mapColors[selectedMapType]}`}>
                <strong>{selectedDefinition.simpleName}</strong>
                <p>{selectedDefinition.description}</p>
                <div className="definition-tags">
                  {selectedDefinition.examples.map((item) => (
                    <span key={item}>{item}</span>
                  ))}
                </div>
              </div>
            </>
          ) : (
            <button className="sidebar-open-button" onClick={() => setShowLayerPanel(true)}>
              <Layers3 size={18} />
            </button>
          )}
        </aside>

        <div className={`large-map ${mapColors[selectedMapType]}`}>
          <div className="map-bg" />
          <div className="map-gradient" />
          <div className="land land-1" />
          <div className="land land-2" />
          <div className="land land-3" />
          <div className="route route-1" />
          <div className="route route-2" />
          <div className="river" />

          {result.mapMarkers.map((marker, index) => (
            <div
              key={marker.label}
              className={`map-marker marker-${index}`}
              style={{ left: `${marker.x}%`, top: `${marker.y}%` }}
            >
              <MapPin size={15} />
              <span>{marker.label}</span>
            </div>
          ))}

          <div className="map-tools">
            <button>+</button>
            <button>−</button>
            <button><Navigation size={15} /></button>
          </div>

          <div className="map-floating-info">
            <div>
              <Layers3 size={17} />
              <strong>{selectedDefinition.label}</strong>
            </div>
            <p>{result.mapMarkers.length} highlighted locations</p>
          </div>
        </div>
      </div>
    </section>
  );
}

export default MapWorkspace;
