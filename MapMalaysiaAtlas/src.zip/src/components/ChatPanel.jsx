import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  Bot,
  User,
  Send,
  Volume2,
  Square,
  Sparkles,
  Search,
} from "lucide-react";
import { popularQueries } from "../data/mockAtlasData";

function splitWords(text) {
  return text.match(/\S+\s*/g) || [];
}

function ChatPanel({ messages, query, setQuery, onSearch, result }) {
  const [speaking, setSpeaking] = useState(false);
  const [currentWordIndex, setCurrentWordIndex] = useState(-1);
  const messagesEndRef = useRef(null);
  const messagesContainerRef = useRef(null);
  const [showPromptChips, setShowPromptChips] = useState(true);
  const latestAnswerWords = useMemo(
    () => splitWords(result.userFriendlyAnswer),
    [result.userFriendlyAnswer],
  );

  useEffect(() => {
    const box = messagesContainerRef.current;
    if (!box) return;

    box.scrollTo({
      top: box.scrollHeight,
      behavior: "smooth",
    });
  }, [messages]);

  useEffect(() => {
    stopSpeaking();
    return () => stopSpeaking();
  }, [result.userFriendlyAnswer]);

  function speakAnswer() {
    if (!window.speechSynthesis)
      return alert("Text-to-speech is not supported in this browser.");

    window.speechSynthesis.cancel();
    setSpeaking(true);
    setCurrentWordIndex(0);

    const utterance = new SpeechSynthesisUtterance(result.userFriendlyAnswer);
    utterance.rate = 0.92;

    utterance.onboundary = (event) => {
      if (event.name !== "word") return;
      const spokenText = result.userFriendlyAnswer.slice(0, event.charIndex);
      const wordsBefore = spokenText.trim()
        ? spokenText.trim().split(/\s+/).length
        : 0;
      setCurrentWordIndex(wordsBefore);
    };

    utterance.onend = () => {
      setSpeaking(false);
      setCurrentWordIndex(-1);
    };

    utterance.onerror = () => {
      setSpeaking(false);
      setCurrentWordIndex(-1);
    };

    window.speechSynthesis.speak(utterance);
  }

  function stopSpeaking() {
    if (window.speechSynthesis) window.speechSynthesis.cancel();
    setSpeaking(false);
    setCurrentWordIndex(-1);
  }

  function submit(event) {
    event?.preventDefault();
    onSearch(query);
  }

  return (
    <section className="chat-panel">
      <div className="chat-header">
        <div>
          <span className="section-kicker">
            <Sparkles size={14} /> AI Atlas Chat
          </span>
          <h2>Ask about Malaysia</h2>
        </div>

        <div className="voice-actions">
          <button type="button" onClick={speakAnswer}>
            <Volume2 size={12} />
            Listen
          </button>
          <button
            type="button"
            onClick={stopSpeaking}
            className="danger-button"
          >
            <Square size={12} />
            Stop
          </button>
        </div>
      </div>

      <div className="chat-messages" ref={messagesContainerRef}>
        {messages.map((message, index) => {
          const isLatestAi =
            message.role === "ai" && index === messages.length - 1;

          return (
            <div key={index} className={`message-row ${message.role}`}>
              <div className="message-avatar">
                {message.role === "ai" ? <Bot size={16} /> : <User size={16} />}
              </div>

              <div className="message-bubble">
                {isLatestAi && speaking
                  ? latestAnswerWords.map((word, wordIndex) => (
                      <span
                        key={`${word}-${wordIndex}`}
                        className={
                          wordIndex <= currentWordIndex
                            ? "spoken-word"
                            : wordIndex === currentWordIndex + 1
                              ? "next-word"
                              : ""
                        }
                      >
                        {word}
                      </span>
                    ))
                  : message.text}
              </div>
            </div>
          );
        })}
        <div ref={messagesEndRef} />
      </div>

      <div className="chat-tools-row">
        <button
          type="button"
          className="mini-toggle"
          onClick={() => setShowPromptChips(!showPromptChips)}
        >
          {showPromptChips ? "Hide suggestions" : "Show suggestions"}
        </button>
      </div>

      {showPromptChips && (
        <div className="prompt-chips">
          <button
            type="button"
            onClick={() => onSearch("What can I visit in Penang?")}
          >
            What can I visit in Penang?
          </button>

          <button
            type="button"
            onClick={() =>
              onSearch("Show tourism places in Selangor near hospitals")
            }
          >
            Show tourism places in Selangor near hospitals
          </button>

          <button
            type="button"
            onClick={() =>
              onSearch("Show industrial areas near highways in Johor")
            }
          >
            Show industrial areas near highways in Johor
          </button>

          <button
            type="button"
            onClick={() => onSearch("Show flood risk areas in Kelantan")}
          >
            Show flood risk areas in Kelantan
          </button>
        </div>
      )}

      <div className="chat-input">
        <input
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          onKeyDown={(event) => event.key === "Enter" && submit(event)}
          placeholder="Ask about places, transport, tourism..."
        />
        <button type="button" onClick={submit}>
          <Send size={17} />
        </button>
      </div>
    </section>
  );
}

export default ChatPanel;
