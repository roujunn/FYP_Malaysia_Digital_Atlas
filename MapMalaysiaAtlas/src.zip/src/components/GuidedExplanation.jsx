import React from "react";
import { Sparkles } from "lucide-react";

function GuidedExplanation({ result }) {
  return (
    <section className="card-section guide-card">
      <span className="section-kicker"><Sparkles size={14} /> How it works</span>
      <h2>How the system answered</h2>

      <div className="step-grid">
        {result.steps.map((step, index) => (
          <div className="step-card" key={step}>
            <span>{index + 1}</span>
            <p>{step}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

export default GuidedExplanation;
