import { demoScenarios } from "../data/mockAtlasData";

export function processQuery(query) {
  const normalized = query.toLowerCase();

  if (
    normalized.includes("flood") ||
    normalized.includes("river") ||
    normalized.includes("kelantan") ||
    normalized.includes("terrain")
  ) {
    return { ...demoScenarios.physical, query };
  }

  if (
    normalized.includes("highway") ||
    normalized.includes("industrial") ||
    normalized.includes("logistic") ||
    normalized.includes("road") ||
    normalized.includes("johor")
  ) {
    return { ...demoScenarios.logistics, query };
  }

  if (
    normalized.includes("tourism") ||
    normalized.includes("hospital") ||
    normalized.includes("selangor") ||
    normalized.includes("attraction")
  ) {
    return { ...demoScenarios.tourism, query };
  }

  return { ...demoScenarios.general, query };
}
