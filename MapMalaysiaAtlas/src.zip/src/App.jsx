import React, { useMemo, useState } from "react";
import { Map, Moon, Sun, Sparkles } from "lucide-react";
import MapWorkspace from "./components/MapWorkspace";
import ChatPanel from "./components/ChatPanel";
import RelatedPlaces from "./components/RelatedPlaces";
import GuidedExplanation from "./components/GuidedExplanation";
import AdvancedAnalysis from "./components/AdvancedAnalysis";
import NotificationToast from "./components/NotificationToast";
import { demoScenarios } from "./data/mockAtlasData";
import { processQuery } from "./services/queryProcessor";
import "./styles/App.css";

function App() {
  const [theme, setTheme] = useState("light");
  const [query, setQuery] = useState("");
  const [result, setResult] = useState(demoScenarios.general);
  const [selectedMapType, setSelectedMapType] = useState("tourism");
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [notification, setNotification] = useState(
    "Ready to explore Malaysia.",
  );
  const [messages, setMessages] = useState([
    {
      role: "ai",
      text: "Hi! Ask me about places, tourism, transport, or environmental areas in Malaysia.",
    },
    { role: "user", text: demoScenarios.general.query },
    { role: "ai", text: demoScenarios.general.userFriendlyAnswer },
  ]);

  const modeLabel = useMemo(() => {
    if (selectedMapType === "tourism") return "Travel & Places";
    if (selectedMapType === "transport") return "Roads & Transport";
    if (selectedMapType === "physical") return "Nature & Environment";
    return "States & Districts";
  }, [selectedMapType]);

  function handleSearch(nextQuery = query) {
    const cleanQuery = nextQuery.trim();
    if (!cleanQuery) return;

    const processedResult = processQuery(cleanQuery);
    setResult(processedResult);
    setSelectedMapType(processedResult.recommendedMapType);
    setQuery("");
    setShowAdvanced(false);
    setNotification("Map and answer updated.");

    setMessages((prev) => [
      ...prev,
      { role: "user", text: cleanQuery },
      { role: "ai", text: processedResult.userFriendlyAnswer },
    ]);
  }

  return (
    <div className={`app ${theme}`}>
      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />

      <header className="site-header">
        <div className="brand">
          <div className="brand-mark">
            <Map size={22} />
          </div>
          <div>
            <h1>Malaysia AI Digital Atlas</h1>
            <p>Chat with Malaysia’s map intelligence</p>
          </div>
        </div>

        <div className="header-actions">
          <div className="mode-pill">
            <Sparkles size={15} />
            {modeLabel}
          </div>
          <button
            className="theme-toggle"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          >
            {theme === "dark" ? <Sun size={17} /> : <Moon size={17} />}
            {theme === "dark" ? "Light" : "Dark"}
          </button>
        </div>
      </header>

      <main className="page-container chat-version">
        <section className="intro-strip">
          <div>
            <span>Conversational Geographical Intelligence</span>
            <h2>Ask a question. See the answer on the map.</h2>
          </div>
          <p>
            Designed for general users, tourists, and logistics users. Technical
            AI details are hidden until needed.
          </p>
        </section>

        <section className="map-chat-layout">
          <MapWorkspace
            result={result}
            selectedMapType={selectedMapType}
            setSelectedMapType={setSelectedMapType}
          />

          <ChatPanel
            messages={messages}
            query={query}
            setQuery={setQuery}
            onSearch={handleSearch}
            result={result}
          />
        </section>

        <section className="support-layout">
          <RelatedPlaces result={result} />
          <GuidedExplanation result={result} />
        </section>

        <section className="advanced-layout">
          <AdvancedAnalysis
            result={result}
            showAdvanced={showAdvanced}
            setShowAdvanced={setShowAdvanced}
          />
        </section>
      </main>

      <NotificationToast
        message={notification}
        onClose={() => setNotification("")}
      />
    </div>
  );
}

export default App;
