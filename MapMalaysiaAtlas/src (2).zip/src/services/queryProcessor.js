import { demoScenarios } from "../data/mockAtlasData";
export function processQuery(query) {
  const n = query.toLowerCase();
  if (n.includes("postcode") || n.includes("postal") || n.includes("post code")) return { ...demoScenarios.postal, query };
  if (n.includes("parliament") || n.includes("representative") || n.includes("constituency") || n.includes("political") || n.includes("government") || n.includes("dun")) return { ...demoScenarios.political, query };
  if (n.includes("amenity") || n.includes("amenities") || n.includes("church") || n.includes("school") || n.includes("market") || n.includes("socio")) return { ...demoScenarios.socioeconomic, query };
  if (n.includes("kampung") || n.includes("taman") || n.includes("boundary") || n.includes("boundaries") || n.includes("district") || n.includes("mukim") || n.includes("administrative")) return { ...demoScenarios.administrative, query };
  if (n.includes("flood") || n.includes("river") || n.includes("kelantan") || n.includes("terrain") || n.includes("physical") || n.includes("mountain")) return { ...demoScenarios.physical, query };
  if (n.includes("highway") || n.includes("industrial") || n.includes("logistic") || n.includes("road") || n.includes("johor") || n.includes("mrt") || n.includes("lrt") || n.includes("rail") || n.includes("boat") || n.includes("ferry") || n.includes("transport")) return { ...demoScenarios.logistics, query };
  if (n.includes("tourism") || n.includes("hospital") || n.includes("selangor") || n.includes("attraction") || n.includes("tourist") || n.includes("visit")) return { ...demoScenarios.tourism, query };
  return { ...demoScenarios.general, query };
}
