export const mapTypeDefinitions = {
  administrative: { label: "Administrative Map", simpleName: "Administrative Map", short: "Boundaries & Areas", description: "Shows the administrative hierarchy and boundaries of Malaysia, including states, districts, mukim, towns, kampung and taman. It helps users understand which area a place belongs to.", examples: ["State", "District", "Mukim", "Kampung", "Taman"] },
  political: { label: "Political Map", simpleName: "Political Map", short: "Governance & Rep", description: "Shows governance-related areas such as parliament seats, state constituencies, local authority areas and representatives. It can support questions about who represents an area or how political boundaries change over time.", examples: ["Parliament", "DUN", "Representative", "Local Authority"] },
  transport: { label: "Transportation Map", simpleName: "Transportation Map", short: "Routes & Networks", description: "Shows transport networks such as roads, highways, railways, MRT, LRT, KTM, bus routes, ferry terminals and boat routes. It helps users understand movement and connectivity.", examples: ["Road", "Rail", "MRT/LRT", "Bus", "Boat route"] },
  physical: { label: "Physical Map", simpleName: "Physical Map", short: "Terrain & Nature", description: "Shows natural features such as rivers, mountains, terrain, forests, coastal areas, water bodies and environmental risk zones.", examples: ["River", "Mountain", "Forest", "Terrain", "Coast"] },
  tourism: { label: "Tourism Map", simpleName: "Tourism Map", short: "Attractions & POIs", description: "Shows attractions, landmarks, heritage areas, food streets, hotels, museums and other points of interest for visitors.", examples: ["Attraction", "Landmark", "Food", "Hotel", "Museum"] },
  socioeconomic: { label: "Socio-Economic Map", simpleName: "Socio-Economic Map", short: "Amenities & Services", description: "Shows amenities and social facilities such as schools, hospitals, religious places, markets, community facilities and economic activity areas.", examples: ["School", "Hospital", "Church", "Market", "Amenity"] },
  postal: { label: "Postal Map", simpleName: "Postal Map", short: "Postcodes & Zones", description: "Shows postcode zones and postal delivery areas. It helps users understand which postcode belongs to a place or which areas share the same postal zone.", examples: ["Postcode", "Postal zone", "Delivery area", "Address"] },
};

export const demoScenarios = {
  general: {
    query: "What can I visit in Penang?",
    title: "Recommended places to explore in Penang",
    recommendedMapType: "tourism",
    focus: "George Town, Penang",
    summary:
      "George Town is a good starting point because it has cultural attractions, food areas, heritage streets, and nearby public facilities.",
    userFriendlyAnswer:
      "You can start around George Town. It is suitable for general exploration because it combines heritage streets, cafes, museums, and nearby transport access. For a first visit, focus on the heritage core, nearby food streets, and waterfront areas.",
    relatedPlaces: [
      { name: "George Town Heritage Area", type: "Cultural Area", note: "Good for walking and sightseeing." },
      { name: "Penang Street Food Zone", type: "Food Area", note: "Suitable for local food discovery." },
      { name: "Waterfront Area", type: "Scenic Place", note: "Good for evening visits." },
      { name: "Nearby Transport Stop", type: "Transport", note: "Useful for planning movement." },
    ],
    mapMarkers: [
      { label: "Heritage Area", x: 42, y: 42, type: "Cultural area", distance: "0.8 km from George Town center", description: "A demo marker for heritage streets and cultural attractions." },
      { label: "Food Street", x: 54, y: 56, type: "Food area", distance: "1.2 km from Heritage Area", description: "A demo marker for food discovery and visitor activity." },
      { label: "Waterfront", x: 66, y: 38, type: "Scenic place", distance: "1.6 km from Heritage Area", description: "A demo marker for scenic viewing and evening visits." },
    ],
    spatialAnalysis: {
      queryType: "Proximity + tourism filter",
      center: "George Town",
      radius: "Within 2 km",
      explanation: "The demo simulates a spatial query that finds nearby visitor places around George Town and displays them as highlighted map markers.",
      results: [
        { name: "Heritage Area", type: "Cultural area", distance: "0.8 km", note: "Inside the selected exploration area." },
        { name: "Food Street", type: "Food area", distance: "1.2 km", note: "Near the heritage core." },
        { name: "Waterfront", type: "Scenic place", distance: "1.6 km", note: "Suitable for evening route planning." },
      ],
    },
    steps: [
      "Detected that the question is about places to visit.",
      "Identified Penang and George Town as the main area.",
      "Selected the tourism map because attractions and food places are relevant.",
      "Highlighted suitable places and generated an easy answer.",
    ],
    graph: [
      ["George Town", "located in", "Penang"],
      ["George Town", "has attraction", "Heritage Area"],
      ["Food Street", "near", "George Town"],
      ["Waterfront", "suitable for", "Scenic Visit"],
    ],
  },
  tourism: {
    query: "Show tourism places in Selangor near hospitals",
    title: "Tourism places in Selangor with nearby facilities",
    recommendedMapType: "tourism",
    focus: "Selangor",
    summary:
      "The system selected the tourism map and checked nearby facilities to support safer trip planning.",
    userFriendlyAnswer:
      "Selangor has several suitable tourism areas with nearby public facilities. The highlighted places can help users explore attractions while staying close to hospitals or emergency services.",
    relatedPlaces: [
      { name: "Shah Alam", type: "City", note: "Main urban area with facilities." },
      { name: "Tourism Area", type: "Attraction Cluster", note: "Suitable for visitors." },
      { name: "Hospital POI", type: "Facility", note: "Nearby healthcare support." },
      { name: "Transport Access", type: "Transport", note: "Useful for reaching the area." },
    ],
    mapMarkers: [
      { label: "Shah Alam", x: 38, y: 54, type: "City", distance: "0 km center", description: "The main administrative and urban reference point in this demo query." },
      { label: "Tourism Area", x: 48, y: 46, type: "Attraction cluster", distance: "4.3 km from Shah Alam", description: "A simulated tourism cluster selected from the mock atlas data." },
      { label: "Hospital POI", x: 58, y: 57, type: "Healthcare facility", distance: "2.1 km from Tourism Area", description: "A simulated nearby hospital used to demonstrate accessibility filtering." },
    ],
    spatialAnalysis: {
      queryType: "Radius + facility proximity",
      center: "Tourism Area, Selangor",
      radius: "Within 5 km",
      explanation: "The demo simulates checking whether tourism locations are near healthcare facilities, which supports safer trip planning.",
      results: [
        { name: "Tourism Area", type: "Attraction cluster", distance: "0 km", note: "Selected as the main visitor location." },
        { name: "Hospital POI", type: "Healthcare facility", distance: "2.1 km", note: "Within the 5 km demo radius." },
        { name: "Shah Alam", type: "City", distance: "4.3 km", note: "Nearby urban support area." },
      ],
    },
    steps: [
      "Detected a tourism and facility-related query.",
      "Identified Selangor as the main location.",
      "Selected tourism and infrastructure-related map information.",
      "Highlighted attractions and nearby hospitals for easier planning.",
    ],
    graph: [
      ["Selangor", "contains", "Shah Alam"],
      ["Tourism Area", "located in", "Selangor"],
      ["Tourism Area", "near", "Hospital POI"],
      ["Hospital POI", "type", "Facility"],
    ],
  },
  logistics: {
    query: "Show industrial areas near highways in Johor",
    title: "Industrial areas with highway access in Johor",
    recommendedMapType: "transport",
    focus: "Johor",
    summary:
      "The system selected the transport map because the query is about highway access and industrial connectivity.",
    userFriendlyAnswer:
      "For logistics planning, the system highlights industrial areas that are close to highway routes. These areas are useful for checking transport access, warehouse suitability, and regional connectivity.",
    relatedPlaces: [
      { name: "Industrial Area", type: "Business Zone", note: "Suitable for logistics analysis." },
      { name: "Highway Route", type: "Road Network", note: "Supports regional movement." },
      { name: "Nearby City", type: "Urban Area", note: "Potential demand and workforce area." },
      { name: "Transport Node", type: "Connectivity", note: "Useful for accessibility checking." },
    ],
    mapMarkers: [
      { label: "Industrial Area", x: 50, y: 52, type: "Business zone", distance: "1.4 km from highway", description: "A simulated industrial location for logistics suitability checking." },
      { label: "Highway Route", x: 60, y: 43, type: "Road network", distance: "Near Industrial Area", description: "A simulated highway route used for accessibility analysis." },
      { label: "Transport Node", x: 42, y: 64, type: "Connectivity point", distance: "3.2 km from Industrial Area", description: "A simulated transport access point for regional movement." },
    ],
    spatialAnalysis: {
      queryType: "Accessibility + proximity",
      center: "Industrial Area, Johor",
      radius: "Within 5 km of highway access",
      explanation: "The demo simulates identifying industrial areas that are close to highway routes for logistics planning.",
      results: [
        { name: "Industrial Area", type: "Business zone", distance: "1.4 km", note: "Close to highway access." },
        { name: "Highway Route", type: "Road network", distance: "Near", note: "Supports regional transport connectivity." },
        { name: "Transport Node", type: "Connectivity point", distance: "3.2 km", note: "Useful for freight or movement planning." },
      ],
    },
    steps: [
      "Detected a logistics and accessibility query.",
      "Identified Johor as the target area.",
      "Selected the transport map to show roads and connectivity.",
      "Highlighted industrial areas near highway routes.",
    ],
    graph: [
      ["Industrial Area", "located in", "Johor"],
      ["Industrial Area", "near", "Highway Route"],
      ["Highway Route", "connects", "Nearby City"],
      ["Transport Node", "supports", "Logistics Access"],
    ],
  },
  physical: {
    query: "Show flood risk areas in Kelantan",
    title: "Flood-risk context in Kelantan",
    recommendedMapType: "physical",
    focus: "Kelantan",
    summary:
      "The system selected the physical map because flood-risk questions are related to rivers, terrain, and environmental areas.",
    userFriendlyAnswer:
      "Kelantan is shown with a physical and environmental context. The highlighted areas represent a simplified flood-risk view using river buffer and district overlap logic.",
    relatedPlaces: [
      { name: "Kelantan", type: "State", note: "Main selected area." },
      { name: "River Buffer", type: "Environmental Area", note: "Used for nearby-risk checking." },
      { name: "Risk District", type: "District", note: "Area overlapping the risk zone." },
      { name: "Flood Layer", type: "Map Layer", note: "Visualizes affected areas." },
    ],
    mapMarkers: [
      { label: "Kelantan", x: 54, y: 28, type: "State", distance: "Selected area", description: "The selected state context for the environmental query." },
      { label: "River Buffer", x: 46, y: 37, type: "Environmental buffer", distance: "500 m simulated buffer", description: "A simulated river buffer used to identify nearby flood-risk areas." },
      { label: "Risk District", x: 60, y: 42, type: "District", distance: "Intersects river buffer", description: "A simulated district overlapping with the environmental risk zone." },
    ],
    spatialAnalysis: {
      queryType: "Intersect + buffer",
      center: "Kelantan river context",
      radius: "500 m buffer",
      explanation: "The demo simulates a spatial intersect operation between district areas and river buffer zones to show flood-risk context.",
      results: [
        { name: "River Buffer", type: "Environmental buffer", distance: "500 m", note: "Used as the simplified risk area." },
        { name: "Risk District", type: "District", distance: "Intersects", note: "Overlaps with the buffer zone." },
        { name: "Kelantan", type: "State", distance: "Contains result", note: "Parent administrative area." },
      ],
    },
    steps: [
      "Detected an environmental or flood-related query.",
      "Identified Kelantan as the target area.",
      "Selected the physical map because rivers and terrain are relevant.",
      "Highlighted areas that overlap with the simplified flood-risk context.",
    ],
    graph: [
      ["Kelantan", "contains", "Risk District"],
      ["Risk District", "intersects", "River Buffer"],
      ["River Buffer", "distance", "500m"],
      ["Flood Layer", "visualizes", "Risk Area"],
    ],
  },
  administrative: { query: "Explain kampung and taman boundaries in Melaka", title: "Administrative hierarchy and local area boundaries", recommendedMapType: "administrative", focus: "Melaka Tengah", summary: "The administrative map helps users understand how places are organized from state to district, town, kampung and taman.", userFriendlyAnswer: "The administrative map shows the boundary structure of an area. For example, Melaka contains districts, districts contain towns or mukim, and smaller named areas such as kampung and taman can be shown as local settlement areas.", relatedPlaces: [], mapMarkers: [ { label: "Melaka Tengah", x: 48, y: 45, type: "District", distance: "Selected district", description: "Main administrative district used for the demo boundary view." }, { label: "Taman Merdeka", x: 61, y: 48, type: "Taman", distance: "Inside district", description: "Example local residential area within the administrative hierarchy." }, { label: "Kampung Bukit Katil", x: 40, y: 32, type: "Kampung", distance: "Inside district", description: "Example village area shown under administrative map context." } ], spatialAnalysis: { queryType: "Containment / boundary lookup", center: "Melaka Tengah", radius: "Within administrative boundary", explanation: "The demo simulates checking which smaller named areas are contained inside a district boundary.", results: [ { name: "Melaka Tengah", type: "District", distance: "Parent area", note: "Main selected administrative boundary." }, { name: "Taman Merdeka", type: "Taman", distance: "Contained", note: "Example local area inside the district." }, { name: "Kampung Bukit Katil", type: "Kampung", distance: "Contained", note: "Example kampung inside the district." } ] }, steps: [ "Detected an administrative boundary query.", "Identified the main area and smaller local place types.", "Selected the administrative map to show hierarchy and containment.", "Highlighted district, kampung and taman examples on the map." ], graph: [ ["Melaka", "contains", "Melaka Tengah"], ["Melaka Tengah", "contains", "Taman Merdeka"], ["Melaka Tengah", "contains", "Kampung Bukit Katil"], ["Administrative Map", "explains", "Area hierarchy"] ] },
  political: { query: "List parliament representatives for this area", title: "Political representation and governance area", recommendedMapType: "political", focus: "Selected constituency area", summary: "The political map helps users understand parliament or state constituency boundaries and representation.", userFriendlyAnswer: "This political map view demonstrates how the atlas can show parliament seats, representative areas and governance boundaries. In the full version, this can be connected to official election or parliament datasets.", relatedPlaces: [], mapMarkers: [ { label: "Parliament Area", x: 45, y: 42, type: "Parliament boundary", distance: "Selected area", description: "Demo parliamentary area boundary." }, { label: "DUN Area", x: 58, y: 50, type: "State constituency", distance: "Inside parliament area", description: "Demo state constituency area." }, { label: "Local Authority", x: 52, y: 62, type: "Governance area", distance: "Overlapping area", description: "Demo local authority area." } ], spatialAnalysis: { queryType: "Boundary overlap", center: "Selected political area", radius: "Constituency boundary", explanation: "The demo simulates checking how parliament, state constituency and local authority areas overlap.", results: [ { name: "Parliament Area", type: "Political boundary", distance: "Selected", note: "Main representative boundary." }, { name: "DUN Area", type: "State constituency", distance: "Inside", note: "Smaller political area." }, { name: "Local Authority", type: "Governance", distance: "Overlaps", note: "Administration-related area." } ] }, steps: [ "Detected a political or representative-related query.", "Identified the relevant governance boundary.", "Selected the political map to show constituencies and representatives.", "Displayed linked boundaries for explanation." ], graph: [ ["Parliament Area", "contains", "DUN Area"], ["Representative", "serves", "Parliament Area"], ["Local Authority", "overlaps", "DUN Area"], ["Political Map", "visualizes", "Governance boundary"] ] },
  socioeconomic: { query: "Show amenities and churches near this area", title: "Amenities and social facilities nearby", recommendedMapType: "socioeconomic", focus: "Community facilities area", summary: "The socio-economic map highlights amenities, services and community facilities.", userFriendlyAnswer: "The socio-economic map can show public amenities such as schools, hospitals, markets, religious places and community facilities. This helps users understand the service profile of an area.", relatedPlaces: [], mapMarkers: [ { label: "School", x: 44, y: 39, type: "Amenity", distance: "1.1 km", description: "Example education amenity." }, { label: "Hospital", x: 55, y: 50, type: "Healthcare", distance: "2.0 km", description: "Example healthcare facility." }, { label: "Church", x: 63, y: 58, type: "Religious place", distance: "2.8 km", description: "Example religious facility." } ], spatialAnalysis: { queryType: "Amenity proximity", center: "Selected community area", radius: "Within 3 km", explanation: "The demo simulates searching nearby amenities within a selected community area.", results: [ { name: "School", type: "Education", distance: "1.1 km", note: "Nearby community service." }, { name: "Hospital", type: "Healthcare", distance: "2.0 km", note: "Nearby public facility." }, { name: "Church", type: "Religious place", distance: "2.8 km", note: "Nearby social facility." } ] }, steps: [ "Detected an amenity or community facility query.", "Identified facilities such as schools, hospitals and religious places.", "Selected the socio-economic map.", "Highlighted nearby amenities for area understanding." ], graph: [ ["Community Area", "has amenity", "School"], ["Community Area", "has amenity", "Hospital"], ["Community Area", "has amenity", "Church"], ["Socio-Economic Map", "shows", "Amenities"] ] },
  postal: { query: "Show postcode zones for this area", title: "Postal zone and postcode map", recommendedMapType: "postal", focus: "Selected postcode area", summary: "The postal map helps users understand postcode zones and address-related areas.", userFriendlyAnswer: "The postal map demonstrates postcode zones and delivery areas. In the full system, official postcode or postal boundary data can be connected to support address and area lookup.", relatedPlaces: [], mapMarkers: [ { label: "75000", x: 43, y: 42, type: "Postcode zone", distance: "Selected zone", description: "Example postcode area." }, { label: "75200", x: 56, y: 49, type: "Postcode zone", distance: "Adjacent zone", description: "Example nearby postcode area." }, { label: "75450", x: 62, y: 61, type: "Postcode zone", distance: "Nearby zone", description: "Example postal delivery zone." } ], spatialAnalysis: { queryType: "Postal zone lookup", center: "Selected postcode area", radius: "Postcode boundary", explanation: "The demo simulates finding postcode zones and nearby postal areas.", results: [ { name: "75000", type: "Postcode", distance: "Selected", note: "Main postcode zone." }, { name: "75200", type: "Postcode", distance: "Adjacent", note: "Nearby postcode zone." }, { name: "75450", type: "Postcode", distance: "Nearby", note: "Additional postal zone." } ] }, steps: [ "Detected a postcode or postal area query.", "Selected the postal map.", "Checked the relevant postcode zone.", "Highlighted nearby postal zones for comparison." ], graph: [ ["Postal Map", "contains", "75000"], ["75000", "adjacent to", "75200"], ["75200", "near", "75450"], ["Postcode", "belongs to", "Address Area"] ] }
};

export const popularQueries = [
  "Explain kampung and taman boundaries in Melaka",
  "List parliament representatives for this area",
  "Show MRT, roads and boat routes in Kuala Lumpur",
  "Show flood risk areas in Kelantan",
  "Show tourism places in Selangor near hospitals",
  "Show amenities and churches near this area",
  "Show postcode zones for this area",
];
